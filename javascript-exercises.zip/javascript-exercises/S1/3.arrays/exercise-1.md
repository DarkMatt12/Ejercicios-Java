Consigue el valor "Volvo" del array de cars y muestralo por consola.

```js
const cars = ["Saab", "Volvo", "BMW"];
```