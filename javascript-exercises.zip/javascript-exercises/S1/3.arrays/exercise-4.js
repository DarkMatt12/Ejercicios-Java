const RickAndMortyCharacters = ["Rick", "Beth", "Jerry"];
RickAndMortyCharacters.push("Morty", "Summer");
console.log(RickAndMortyCharacters[RickAndMortyCharacters.length - 1]);