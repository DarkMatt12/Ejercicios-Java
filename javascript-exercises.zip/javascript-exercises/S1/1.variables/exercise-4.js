const character = {name: 'Jack Sparrow', age: 10};
character.age = 25;