const div$$ = document.createElement("div");

document.body.appendChild(div$$);