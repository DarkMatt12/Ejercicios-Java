const allP$$ = document.body.querySelectorAll('p');

console.log(allP$$);