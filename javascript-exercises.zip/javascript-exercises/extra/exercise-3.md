En base al siguiente array cuenta cuantas letras "a" tenemos. El resultado debería ser 9.

```js
const animals = ["Salamandra montesa", "Delinicio", "Tigre de puntos", "Saltamontañas"]
```