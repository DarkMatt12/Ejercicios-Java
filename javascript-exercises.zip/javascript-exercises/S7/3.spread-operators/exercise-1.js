const pointsList = [32, 54, 21, 64, 75, 43]

const pointsListCopy = [...pointsList];
